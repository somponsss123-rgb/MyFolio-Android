# MyFolio V10.3

แอป Android (WebView) สำหรับติดตามพอร์ตการลงทุน หน้าแอปอยู่ที่ `app/src/main/assets/index.html`

## สร้าง APK บน GitHub
1. อัปโหลดทั้งโฟลเดอร์นี้ขึ้น repository (รวมโฟลเดอร์ `.github`)
2. ไปที่แท็บ **Actions** > **Build APK** > **Run workflow**
3. รอจนเสร็จ แล้วดาวน์โหลดไฟล์ APK จากหัวข้อ **Artifacts** (`MyFolio-apk`)

ไม่ต้องมี `gradle-wrapper.jar` เพราะ workflow ติดตั้ง Gradle ให้เอง

## เซ็นชื่อ release (ไม่บังคับ)
เพิ่ม Secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
ถ้าไม่ตั้ง ไฟล์ release จะเซ็นด้วยกุญแจ debug (ติดตั้งได้ แต่ยังส่ง Play Store ไม่ได้)

## หมายเหตุ
แถบราคาสดและกราฟใช้วิดเจ็ตของ TradingView ต้องต่ออินเทอร์เน็ต ส่วนตัวเลขมูลค่าพอร์ตคำนวณจากราคาที่ดึงเองเป็นรอบ ๆ (ตั้งความถี่ได้ที่ปุ่ม LIVE)

## แหล่งราคาที่รองรับ
Yahoo Finance, Bitkub, Binance, CoinGecko, Coinbase, ราคาทอง (thaigoldtoday / ราคาทองโลก) และเว็บอื่นที่ใส่ลิงก์เอง (JSON) — ตั้งต่อสินทรัพย์ได้ที่เมนู "แหล่งราคา"
ลิงก์ที่กำหนดเองต้องเป็น https และไม่ใช่ที่อยู่ในเครือข่ายภายใน
