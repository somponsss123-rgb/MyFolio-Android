-keepclassmembers class com.myfolio.app.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
