package com.myfolio.app

import android.annotation.SuppressLint
import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackup: String? = null
    private val io = Executors.newFixedThreadPool(3)

    /** Price bridge: https only, port 443, and never a private/local network address. */
    private fun isPublicHost(host: String): Boolean = try {
        java.net.InetAddress.getAllByName(host).all { a ->
            !(a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress ||
                a.isSiteLocalAddress || a.isMulticastAddress ||
                (a.address.size == 16 && (a.address[0].toInt() and 0xfe) == 0xfc))
        }
    } catch (e: Exception) { false }

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = chooserCallback
        chooserCallback = null
        val uris = if (r.resultCode == Activity.RESULT_OK)
            WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data) else null
        cb?.onReceiveValue(uris)
    }

    private val saveFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val data = pendingBackup
        pendingBackup = null
        if (uri == null || data == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri, "wt")?.use { it.write(data.toByteArray(Charsets.UTF_8)) }
            toast("บันทึกไฟล์สำรองเรียบร้อย")
        } catch (e: Exception) {
            toast("บันทึกไฟล์ไม่สำเร็จ: ${e.message}")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val bg = ContextCompat.getColor(this, R.color.mf_bg)
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        web = WebView(this).apply { setBackgroundColor(bg) }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // Keep content clear of status/navigation bars and the keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? =
                request?.let { loader.shouldInterceptRequest(it.url) }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                // Let TradingView widgets (iframes) load inside the page; only top-level links leave the app.
                if (request.isForMainFrame.not() || uri.host == HOST) return false
                try {
                    startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri))
                } catch (_: Exception) { }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = filePathCallback
                return try {
                    pickFile.launch(fileChooserParams!!.createIntent())
                    true
                } catch (e: Exception) {
                    chooserCallback = null
                    filePathCallback?.onReceiveValue(null)
                    false
                }
            }
        }

        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (savedInstanceState == null) web.loadUrl("https://$HOST/assets/index.html")
        else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        io.shutdown()
        web.destroy()
        super.onDestroy()
    }

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    private fun reply(id: Int, ok: Boolean, body: String) = runOnUiThread {
        web.evaluateJavascript("window.__nf($id,$ok,${JSONObject.quote(body)})", null)
    }

    inner class Bridge {
        /** Opens the system "Save as" dialog so the user chooses where the backup goes (Downloads, Drive...). */
        @JavascriptInterface
        fun backup(json: String) {
            runOnUiThread {
                pendingBackup = json
                val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                saveFile.launch("portfolio-backup-$stamp.json")
            }
        }

        /** Fetches a public https URL natively (no CORS, no third-party proxy). */
        @JavascriptInterface
        fun fetchText(id: Int, url: String, timeoutMs: Int) {
            io.execute {
                try {
                    var current = url
                    var redirects = 0
                    while (true) {
                        val u = URL(current)
                        require(u.protocol == "https" && (u.port == -1 || u.port == 443) && isPublicHost(u.host)) { "ลิงก์นี้ไม่ได้รับอนุญาต" }
                        val c = u.openConnection() as HttpURLConnection
                        c.instanceFollowRedirects = false
                        c.connectTimeout = timeoutMs.coerceIn(1000, 20000)
                        c.readTimeout = timeoutMs.coerceIn(1000, 20000)
                        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) MyFolio/10.2")
                        c.setRequestProperty("Accept", "application/json,text/html;q=0.9,*/*;q=0.8")
                        val code = c.responseCode
                        if (code in 300..399 && redirects++ < 3) {
                            current = URL(u, c.getHeaderField("Location") ?: error("redirect")).toString()
                            c.disconnect()
                            continue
                        }
                        if (code !in 200..299) error("HTTP $code")
                        val text = c.inputStream.use { it.readBytes().take(2_000_000).toByteArray().toString(Charsets.UTF_8) }
                        c.disconnect()
                        reply(id, true, text)
                        break
                    }
                } catch (e: Exception) {
                    reply(id, false, e.message ?: "เชื่อมต่อไม่ได้")
                }
            }
        }
    }

    companion object {
        private const val HOST = "appassets.androidplatform.net"
    }
}
