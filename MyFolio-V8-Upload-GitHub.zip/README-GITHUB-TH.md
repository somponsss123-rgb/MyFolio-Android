# MyFolio V8 — สร้าง APK ผ่าน GitHub Actions

นี่คือ **โครงการ Android ต้นฉบับ** (ยังไม่ใช่ไฟล์ APK)

## วิธีสร้าง APK บน GitHub (ทำบนคอมพิวเตอร์จะง่ายกว่า)

1. ลงชื่อเข้าใช้ https://github.com แล้วสร้าง Repository ใหม่ชื่อ `MyFolio-Android` แนะนำเลือก **Private**
2. นำไฟล์และโฟลเดอร์ **ด้านใน ZIP นี้** ไปเก็บที่ **รากของ Repository** โดยต้องรักษาโครงสร้างไดเรกทอรี โดยเฉพาะ `.github/workflows/build-apk.yml` อย่าอัปโหลด ZIP ทั้งก้อนเป็นไฟล์เดียว
   - สะดวกสุดหากใช้ GitHub Desktop หรือ `git` เพื่ออัปโหลดทั้งโฟลเดอร์
   - ถ้าจะใช้หน้าเว็บ GitHub กด **Add file > Upload files** แล้วใส่โครงสร้างไฟล์ให้ถูกต้อง
3. เปิดแท็บ **Actions** ใน Repository
4. เลือก **Build MyFolio Android APK** แล้วกด **Run workflow** (กรณีไม่ขึ้นให้ตรวจว่าไฟล์ `.github/workflows/build-apk.yml` อยู่บน branch เริ่มต้น)
5. เมื่อรายการรันสำเร็จ (เครื่องหมายถูกสีเขียว) ให้กดรายการรัน แล้วเลื่อนลงหัวข้อ **Artifacts**
6. ดาวน์โหลด **MyFolio-V8-Android-APK** (จะได้ไฟล์ ZIP จาก GitHub) แล้วแตก ZIP จะพบไฟล์ `app-debug.apk` สำหรับติดตั้ง Android

GitHub Actions จะคอมไพล์ด้วย JDK 17, Gradle 8.9, Android SDK 35 จากซอร์ส MyFolio V8 ที่แนบไว้

## ข้อควรทราบ

- APK ที่ได้เป็น **debug APK** ซึ่งใช้ติดตั้งทดสอบเอง ไม่ใช่แพ็กเกจสำหรับส่ง Google Play Store
- โปรเจกต์นี้ **ยังไม่ได้รัน GitHub Actions จริง** และยังไม่ได้ทดสอบ APK บนอุปกรณ์ Android จริง
- ก่อนติดตั้ง ให้ **สำรอง JSON จาก MyFolio V8 ใน Chrome** ไว้ก่อน เพราะข้อมูลจะไม่ย้ายเข้าแอปเอง
- แอปต้องการอินเทอร์เน็ตเมื่อใช้ดึงราคาตลาด; บางแหล่งอาจตอบกลับช้าหรือไม่อนุญาตให้ดึงจาก WebView
- ถ้า GitHub Actions ล้มเหลว ให้ดู log ใต้ step ที่ขึ้นเครื่องหมายกากบาท ไม่ควรเดาสาเหตุจากภาพหน้าหลักอย่างเดียว
- หากติดตั้งไม่ได้ ให้ตรวจว่าตั้งค่า Android ให้อนุญาตติดตั้งจากแหล่งนั้น และระบบ Android เป็นรุ่น 8.0 ขึ้นไป (minSdk 26)

### โครงสร้างสำคัญของโปรเจกต์

- `.github/workflows/build-apk.yml` — คำสั่งสร้าง APK อัตโนมัติ
- `app/src/main/assets/index.html` — แอป MyFolio V8
- `app/src/main/java/com/myfolio/app/MainActivity.java` — ตัวเปิดหน้าแอปบน Android
- `app/build.gradle` — การตั้งค่า Android
