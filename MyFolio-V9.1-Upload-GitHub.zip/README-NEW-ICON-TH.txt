MyFolio V8.1 — New launcher icon
ไอคอนกระเป๋าเงินพร้อมกราฟลูกศรทอง ตรงตามภาพที่ผู้ใช้เลือก

1) แพ็กเกจนี้แทน MyFolio-V8-Upload-GitHub.zip เดิมบน GitHub
2) Workflow build-apk.yml เดิมจะสร้าง APK ได้อีกครั้งเมื่อ ZIP เปลี่ยน
3) ไม่ต้องเปลี่ยน HTML / ระบบคำนวณ / ระบบซื้อขาย
4) สำรอง JSON ก่อนถอนการติดตั้ง APK รุ่นเดิม เนื่องจาก debug APK ต่างรอบอาจมีลายเซ็นไม่ตรงกัน

Important: A ZIP in GitHub is source, not an APK. GitHub Actions must show a green success check before a usable APK can be downloaded.
