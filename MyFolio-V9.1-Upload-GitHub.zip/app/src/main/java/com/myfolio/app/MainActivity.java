package com.myfolio.app;
import android.widget.Toast;
import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> uploadCallback;
  private String pendingBackup;
  private static final int PICK_JSON=101, SAVE_JSON=102;
  @Override public void onCreate(Bundle b){ super.onCreate(b);
    web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(false);
    WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
    web.setWebViewClient(new WebViewClientCompat(){
      @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request){return loader.shouldInterceptRequest(request.getUrl());}
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
        uploadCallback=callback;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(i,PICK_JSON);return true;}catch(Exception e){uploadCallback=null;return false;}
      }
    });
    web.addJavascriptInterface(new Object(){
      @JavascriptInterface public void backup(String json){runOnUiThread(()->{
        pendingBackup=json;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"myfolio-backup.json");startActivityForResult(i,SAVE_JSON);
      });}
    },"AndroidBridge");
    web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
    if(req==PICK_JSON){if(uploadCallback!=null){uploadCallback.onReceiveValue(result==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);uploadCallback=null;}}
    if(req==SAVE_JSON && result==RESULT_OK&&data!=null&&pendingBackup!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));Toast.makeText(this,"สำรองข้อมูลสำเร็จ",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"สำรองข้อมูลไม่สำเร็จ",Toast.LENGTH_LONG).show();}pendingBackup=null;}
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
